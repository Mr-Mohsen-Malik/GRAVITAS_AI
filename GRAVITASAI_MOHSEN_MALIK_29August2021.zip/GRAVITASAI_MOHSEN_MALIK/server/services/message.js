const { dashboard } = require('../data/data');

const message = {};

message.getDashboardData = (req, res) => {
  res.json(dashboard)
}

message.getCardDataById = (req, res) => {
  let id = req.params.id;
  let cardData = {};

  cardData.filter = dashboard.filter;
  cardData.card = dashboard.cards.find(_card => _card.id == id)

  // global.cLog(dashboard.cards.find(_card => _card.id == id))
  if (cardData.card) {
    res.json(cardData)
  } else {
    res.status(400).send('invalid parameter');
  }
}

module.exports = message;