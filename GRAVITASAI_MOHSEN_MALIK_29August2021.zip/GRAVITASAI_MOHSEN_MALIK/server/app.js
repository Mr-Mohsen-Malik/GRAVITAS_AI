var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var setRoutes = require('./routes');

var app = express();

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "POST");
  res.header("Access-Control-Allow-Headers", "Content-Type, Accept");
  next();
});

app.use('/ping', (req, res) => {
  res.status(200).send("API Called");
});

setRoutes(app);

app.use('/*', function(req, res) {
  res.status(404).send("NOT FOUND");
});

app.use(function(err, req, res, next) {
  res.status(err.status || 500).send("SOMETHING WENT WRONG");
});

module.exports = app;
