var express = require('express');
var messageSrvc = require('./services/message');

const setRoutes = (app) => {

    const router = express.Router();

    router.route("/dashboard").get( (req, res) => {
        // global.cLog("here")
        messageSrvc.getDashboardData(req, res);
    });
    router.route("/card/:id").get( (req, res) => {
        messageSrvc.getCardDataById(req, res);
    });
    app.use('/api/v1', router);
}

module.exports = setRoutes;