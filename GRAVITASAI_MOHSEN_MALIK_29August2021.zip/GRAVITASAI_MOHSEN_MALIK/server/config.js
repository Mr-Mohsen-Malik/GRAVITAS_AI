const csvData = {
  path: __dirname + "/data/klook_october_month_data.csv",

}

//uncomment to allow the fields to be display on chart dropdown
const colNamesForChart =  {
    // currency: "HKD",
    date: "2020-10-01",
    // destination: "hong kong",
    field1: "4",
    id: "7.0",
    // lat_long: "22.294926,114.171585",
    // ota: "Klook",
    price: "12000.0",
    // product_title: "Hong Kong Helicopter Tour",
    // segments: "[\"outdoor adventure\", \"activities & experiences\"]",
    total_booking_count: "3565"
  }



module.exports = { csvData, colNamesForChart }