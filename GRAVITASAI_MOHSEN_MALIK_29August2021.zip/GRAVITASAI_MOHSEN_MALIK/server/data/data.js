const dashboard = {};

//filter date data
dashboard.filter = {
  selectedEportType: 1,
  selectedRange:1,
  fromDate:  "Sat Aug 28 2021 15:19:31 GMT+0530 (India Standard Time)",
  toDate:  "Tue Sep 28 2021 15:19:31 GMT+0530 (India Standard Time)",
  month: 'Aug',
  start: 1,
  end: 30,
  step: 1,

}
//cards data
dashboard.cards = [
  {
    id: 1,
    title: "LIVE CONVERSATION COUNT",
    count: "3.6K",
    data: [{}],
    labels: []
  },
  {
    id: 2,
    title: "TOTAL MESSAGES",
    count: "51.33K",
    data: [{
      data: getRandomDataFromRange(10, 40),
      label: 'Series A'
    }],
    labels: getLabels()
  },
  {
    id: 3,
    title: "TOTAL SENT MESSAGES",
    count: "30.62K",
    data: [{
      data: getRandomDataFromRange(10, 40),
      label: 'Series A'
    }],
    labels: getLabels()
  },
  {
    id: 4,
    title: "TOTAL RECEIVED MESSAGES",
    count: "20.71K",
    data: [{
      data: getRandomDataFromRange(10, 40),
      label: 'Series A'
    }],
    labels: getLabels()
  },
  {
    id: 5,
    title: "TOTAL CONVERSATIONS",
    count: "4.25K",
    data: [{
      data: getRandomDataFromRange(10, 40),
      label: 'Series A'
    }],
    labels: getLabels()
  },
  {
    id: 6,
    title: "AVERAGE SESSION LENGTH",
    count: "2.04 Min",
    data: [{
      data: getRandomDataFromRange(10, 40),
      label: 'Series A'
    }],
    labels: getLabels()
  },
  {
    id: 7,
    title: "AVG. CONV. STEPS/USER",
    count: "1.92",
    data: [{
      data: getRandomDataFromRange(10, 40),
      label: 'Series A'
    }],
    labels: getLabels()
  },
  {
    id: 8,
    title: "AVG. CONV/USER",
    count: "2.07",
    data: [{
      data: getRandomDataFromRange(10, 40),
      label: 'Series A'
    }],
    labels: getLabels()
  },
  {
    id: 9,
    title: "ACTIVE USERS",
    count: "1.5K",
    data: [{
      data: getRandomDataFromRange(10, 40),
      label: 'Series A'
    }],
    labels: getLabels()
  },
  {
    id: 10,
    title: "NEW USERS",
    count: "50",
    data: [{
      data: getRandomDataFromRange(10, 40),
      label: 'Series A'
    }],
    labels: getLabels()
  },
  {
    id: 11,
    title: "RETURNING USERS",
    count: "1.4K",
    data: [{
      data: getRandomDataFromRange(10, 40),
      label: 'Series A'
    }],
    labels: getLabels()
  }
]
//Most activities tables
dashboard.tables = [
  {
    id: 1,
    title: "Most common intents",
    data: [
      { name: "payment", value: "58.4%" },
      { name: "get_a_loan", value: "15%" },
      { name: "consumer_loans", value: "5%" },
      { name: "mortgage", value: "5%" },
      { name: "help", value: "4.5%" },
      { name: "support", value: "4%" }
    ]
  },
  {
    id: 2,
    title: "Most active hours",
    data: [
      { name: "12:00pm-14:30pm", value: "3,929 message" },
      { name: "18:00pm-19:10pm", value: "1,143 messages" },
      { name: "10:00am-11:10am", value: "938 messages" },
      { name: "10:00am-11:10am", value: "938 messages" },
      { name: "10:00am-11:10am", value: "938 messages" },
      { name: "10:00am-11:10am", value: "938 messages" }
    ]
  }
]



function getRandomDataFromRange(min, max ) {
  min = dashboard.filter.start;
  max = dashboard.filter.end;
  // let length = Math.floor(dashboard.filter.end/ dashboard.filter.step);
  return Array.from({ length: max }, _ => Math.floor(Math.random() * (max - min) + min));
}

function getLabels() {
  let start = dashboard.filter.start;
  let step = dashboard.filter.step;
  let stop = dashboard.filter.end;
  let month = dashboard.filter.month;
  // return ['1', '2', '3', '4', '5', '6', '7']

  return Array.from({ length: (stop - start) / step + 1}, (_, i) => `${start + (i * step)}. ${month}`)
}

module.exports = { dashboard }