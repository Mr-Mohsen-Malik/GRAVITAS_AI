import { Component, OnInit } from '@angular/core';
import { faPlusSquare, faFilter, faHeart, faClock } from '@fortawesome/free-solid-svg-icons';
import { DashboardService } from 'src/app/services/dashboard.service';
import { CustomUtilsService } from 'src/app/services/utils/custom-utils.service';
import {chartConfig} from '../../services/app.config';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  public faPlusSquare: any = faPlusSquare;
  public faFilter: any = faFilter;
  public tableIcons: Array<any> = [faHeart, faClock];
  public selectedEportType: any;
  public selectedRange: any;
  public EportTypes: Array<object> = [
    { id: 1, name: "Export to PDF"  },
    { id: 2, name: "Export to CSV" }
]

public CustomRanges: Array<object> = [
  { id: 1, name: "Custom Range"  },
  { id: 2, name: "Custom Range1" },
  { id: 3, name: "Custom Range2" }]

  // lineChart
  public colours: Array<any> = chartConfig.dashboard_chart.colours;
  public legend:boolean = chartConfig.dashboard_chart.legend;
  public options: object = chartConfig.dashboard_chart.options;
  public type: any = chartConfig.dashboard_chart.type;


  public filterData: object = {};
  public dashboardData: object = {};
  public cardsData: Array<any> = [];
  public tablesData: Array<any> = [];
  constructor(private dashboardSrvc: DashboardService, private utilSrvc: CustomUtilsService) { }

  ngOnInit(): void {
    this.dashboardSrvc.getDashboardData().subscribe(data => {
      this.dashboardData = data;
      this.cardsData = data['cards'];
      this.tablesData = data['tables'];
      this.filterData = data['filter'];
      this.onExportTypeChange(this.filterData['selectedEportType']);
      this.onRangeChange(this.filterData['selectedRange']);
      this.utilSrvc.setDate('fromDate', this.filterData['fromDate'])
      this.utilSrvc.setDate('toDate', this.filterData['toDate'])

    });
  }

  onExportTypeChange(id): void {
    this.selectedEportType = this.EportTypes.filter(el => el['id'] == id);
      if(this.selectedEportType.length > 0){
        this.selectedEportType = this.selectedEportType[0].name;
      } else {
        this.selectedEportType = this.EportTypes[0]['name'];
      }
  }
  onRangeChange(id): void {
    this.selectedRange = this.CustomRanges.filter(el => el['id'] == id);
      if(this.selectedRange.length > 0){
        this.selectedRange = this.selectedRange[0].name;
      } else {
        this.selectedRange = this.EportTypes[0]['name'];
      }
    }
}
