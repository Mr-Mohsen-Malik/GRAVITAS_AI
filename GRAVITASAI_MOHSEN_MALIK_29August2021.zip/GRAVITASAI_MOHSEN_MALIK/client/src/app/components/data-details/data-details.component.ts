import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { faFilter, faArrowLeft } from '@fortawesome/free-solid-svg-icons';
import { ChartType } from 'chart.js';
import { DashboardService } from 'src/app/services/dashboard.service';
import { CustomUtilsService } from 'src/app/services/utils/custom-utils.service';
import { chartConfig } from '../../services/app.config';

@Component({
  selector: 'app-data-details',
  templateUrl: './data-details.component.html',
  styleUrls: ['./data-details.component.scss']
})
export class DataDetailsComponent implements OnInit {

  private _id: number;
  public faFilter: any = faFilter;
  public faArrowLeft: any = faArrowLeft;
  public title: string;
  public selectedRange: any;
  public noData: boolean = false;

  public CustomRanges: Array<object> = [
    { id: 1, name: "Custom Range" },
    { id: 2, name: "Two" },
    { id: 3, name: "Three" }
  ]
  // lineChart
  public colours: Array<any> = chartConfig.data_details_chart.colours;
  public legend: boolean = chartConfig.data_details_chart.legend;
  public options: object = chartConfig.data_details_chart.options;
  public type: any = chartConfig.data_details_chart.type;

  public filterData: object = {};
  public cardData: Array<any> = [];
  public cardLabels: Array<any> = [];
  constructor(private dashboardSrvc: DashboardService, private utilSrvc: CustomUtilsService, private route: ActivatedRoute) {
    this._id = parseInt(this.route.snapshot.paramMap.get('id'));
  }

  ngOnInit(): void {
    this.dashboardSrvc.getCardDataById(this._id).subscribe(data => {
      this.cardData = data['card']['data'];
      this.noData = this.cardData.length < 1 || !this.cardData[0]['data'];
      this.cardLabels = data['card']['labels'];
      this.title = data['card']['title']
      this.filterData = data['filter'];
      this.onRangeChange(this.filterData['selectedRange']);
      this.utilSrvc.setDate('fromDate', this.filterData['fromDate'])
      this.utilSrvc.setDate('toDate', this.filterData['toDate'])
      if (!this.noData) {
        setTimeout(() => {
          var chartEl = document.getElementById("myChart");
          chartEl.style.marginTop = "100px";
        }, 10);
      }

    });

  }

  // events
  onRangeChange(id): void {
    this.selectedRange = this.CustomRanges.filter(el => el['id'] == id);
    if (this.selectedRange.length > 0) {
      this.selectedRange = this.selectedRange[0].name;
    } else {
      this.selectedRange = this.CustomRanges[0]['name'];
    }
  }
  chartClicked(e: any): void {
    console.log(e);
  }

  chartHovered(e: any): void {
    console.log(e);
  }

}
