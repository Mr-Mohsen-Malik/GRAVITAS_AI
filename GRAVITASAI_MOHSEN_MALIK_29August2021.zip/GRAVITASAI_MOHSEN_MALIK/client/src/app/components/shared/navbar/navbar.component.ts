import { Component, OnInit, ElementRef } from '@angular/core';
import {Location, LocationStrategy, PathLocationStrategy} from '@angular/common';
import { faChartPie, faPlusCircle, faComment, faUsers, faSyncAlt, faAngleDown } from '@fortawesome/free-solid-svg-icons';
import { Router } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
    location: Location;
    mobile_menu_visible: any = 0;
    private toggleButton: any;
    public faChartPie: any = faChartPie;
    public faPlusCircle: any = faPlusCircle;
    public faComment: any = faComment;
    public faUsers: any = faUsers;
    public faSyncAlt: any = faSyncAlt;
    public faAngleDown: any = faAngleDown;

    constructor(location: Location,  private element: ElementRef, private router: Router) {
      this.location = location;
    }

    ngOnInit(){
      $('#myModal').on('shown.bs.modal', function () {
        $('#myInput').trigger('focus')
      })
    }
}
