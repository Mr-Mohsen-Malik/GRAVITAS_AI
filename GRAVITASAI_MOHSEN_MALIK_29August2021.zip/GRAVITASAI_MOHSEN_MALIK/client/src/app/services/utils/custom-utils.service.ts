import { Injectable } from '@angular/core';
declare var $: any;

@Injectable({
  providedIn: 'root'
})
export class CustomUtilsService {

  constructor() { }

  setDate = (className, dateVal) => {
    var now = new Date(dateVal);
    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);
    var today = now.getFullYear() + "-" + (month) + "-" + (day);
    $(`.${className}`).val(today);
  }
}
