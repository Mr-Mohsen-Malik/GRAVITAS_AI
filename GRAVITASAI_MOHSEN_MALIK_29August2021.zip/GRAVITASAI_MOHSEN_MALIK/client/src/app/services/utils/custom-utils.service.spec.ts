import { TestBed } from '@angular/core/testing';

import { CustomUtilsService } from './custom-utils.service';

describe('CustomUtilsService', () => {
  let service: CustomUtilsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustomUtilsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
