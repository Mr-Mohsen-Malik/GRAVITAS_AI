import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { apis } from './app.config';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(private http: HttpClient) { }

  getDashboardData() {
    return this.http.get(apis.getDashboardData);
  }

  getCardDataById(id) {
    return this.http.get(apis.getCardDataById+id);
  }

  
}
