import { ChartType } from 'chart.js';

const config = {
  serverBaseUrl: "http://localhost:5000/api/",
  serverVersion: "v1/"
}

export const chartConfig = {
  dashboard_chart: {
    options: {
      tooltips: {
        enabled: false,
      },
      maintainAspectRatio: false,
      scales: {
        xAxes: [{
          display: false
        }],
        yAxes: [{
          display: false
        }]
      },
      elements: {
        line: {
            tension: 0.00001,
          borderWidth: 1
        },
        point: {
          radius: 0.000000001,
          hitRadius: 10,
          hoverRadius: 4,
        },
      },
      legend: {
        display: false
      }
    },
    colours: [
      {
        borderColor: 'rgba(8, 174, 224, 0.4)',
        backgroundColor: '#f2fbfd',
      }
    ],
    legend: false,
    type: 'line' as ChartType
  },
  data_details_chart: {
    options: {
      animation: false,
      responsive: true,
      scales: {
        xAxes: [{
          ticks: {
            padding: 10,
            // maxTicksLimit: 25
          },
          gridLines: {
            color: 'transparent',
            zeroLineColor: 'transparent'
          },
          afterTickToLabelConversion: function (data) {
            var xLabels = data.ticks;
            xLabels.forEach(function (labels, i) {
              if (i % 2 == 0) {
                xLabels[i] = '';
              }
            });
          }
        }],
        yAxes: [{
          ticks: {
            padding: 10,
            autoSkip: true,
            stepSize: 2,
            // minTicksLimit: 6

          },
          gridLines: {
            // color: 'transparent',
            autoSkip: true,
            stepSize: 2,
            zeroLineColor: 'transparent'
          },
          afterTickToLabelConversion: function (data) {
            var xLabels = data.ticks;
            xLabels.forEach(function (labels, i) {
              if (i % 2 == 0) {
                xLabels[i] = '';
              }
            });
          }
        }],
      },
      elements: {
        line: {
          tension: 0.00001,
          borderWidth: 2
        },
        point: {
          radius: 5,
          hitRadius: 10,
          hoverRadius: 4,
          borderWidth: 3
        },
      },

    },
    colours: [
      {
        backgroundColor: 'transparent',
        borderColor: 'rgba(8, 174, 224, 0.4)',
        pointBackgroundColor: '#fff',
        pointBorderColor: 'rgba(8, 174, 224, 0.4)',
        pointHoverBackgroundColor: '#fff',
        pointHoverBorderColor: 'rgba(148,159,177,0.8)',
      }
    ],
    legend: false,
    type: 'line' as ChartType
  }
}

export const apis = {
  getDashboardData: config.serverBaseUrl + config.serverVersion + "dashboard/",
  getCardDataById: config.serverBaseUrl + config.serverVersion + "card/",
}
